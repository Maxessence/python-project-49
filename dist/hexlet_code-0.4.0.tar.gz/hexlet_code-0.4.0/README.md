### Hexlet tests and linter status:
[![Actions Status](https://github.com/Maxessence/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Maxessence/python-project-49/actions)

https://asciinema.org/a/QSCu7Pdb5VvpW7qZLLA2vqtEX
