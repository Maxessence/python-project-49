### Hexlet tests and linter status:
[![Actions Status](https://github.com/Maxessence/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Maxessence/python-project-49/actions)

Первый учебный проект "Игры разума" школы Хекслет. 

Серия игр, написанных на Python(версия 3).

Установка - https://asciinema.org/a/KWNPU9y04Jj6aKpS87oxwwL7Q

Запуск игр:
Игра: "Проверка на чётность" - brain-even  
Игра: "Калькулятор" - brain-calc  
Игра "НОД" - brain-gcd  
Игра "Арифметическая прогрессия" - brain-progression  
Игра "Простое ли число?" - brain-prime  

Демонстрация игр:

Игра: "Проверка на чётность" -  https://asciinema.org/a/QSCu7Pdb5VvpW7qZLLA2vqtEX  
Игра: "Калькулятор" - https://asciinema.org/a/P6cAGvXX2U7bwYe9A7Vu9waKt  
Игра "НОД" - https://asciinema.org/a/67jcx5FzIkC3vEI5bdRQ9Hj9I  
Игра "Арифметическая прогрессия" - https://asciinema.org/a/v4CglxamiyySvquaP2Fv2bTJ4  
Игра "Простое ли число?" - https://asciinema.org/a/1pYczWnjaR5wS0Fkwv9R7iMJP  


[![Maintainability](https://api.codeclimate.com/v1/badges/a1d8ba37cc43e498250e/maintainability)](https://codeclimate.com/github/Maxessence/python-project-49/maintainability)
